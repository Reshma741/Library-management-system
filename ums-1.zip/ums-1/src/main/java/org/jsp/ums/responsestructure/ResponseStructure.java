package org.jsp.ums.responsestructure;



public class ResponseStructure {
	
	private int status;
	private String messege;
	private Object body;
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessege() {
		return messege;
	}
	public void setMessege(String messege) {
		this.messege = messege;
	}
	public Object getBody() {
		return body;
	}
	public void setBody(Object body) {
		this.body = body;
	}
	public ResponseStructure() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResponseStructure(int status, String messege, Object body) {
		super();
		this.status = status;
		this.messege = messege;
		this.body = body;
	}
	@Override
	public String toString() {
		return "ResponseStructure [status=" + status + ", messege=" + messege + ", body=" + body + "]";
	}
	
	
	
	

}
