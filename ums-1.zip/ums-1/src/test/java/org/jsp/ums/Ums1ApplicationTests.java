package org.jsp.ums;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ums1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
