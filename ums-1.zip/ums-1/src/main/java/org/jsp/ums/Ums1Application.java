package org.jsp.ums;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ums1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ums1Application.class, args);
	}

}
