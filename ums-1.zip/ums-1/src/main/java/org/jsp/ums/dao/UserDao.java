package org.jsp.ums.dao;


import java.util.List;
import java.util.Optional;

import org.jsp.ums.entity.User;
import org.jsp.ums.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

@Repository
public class UserDao {
	
	@Autowired
	UserRepository repository;

	public User savaUser(User user) {
		
		return repository.save(user);
	}

	

	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}



	public Optional<User> findUser(int id) {
		
		return repository.findById(id);
	}


	public void deleteUser(int id) {
		repository.deleteById(id);
		
		
		
	}


	
}
