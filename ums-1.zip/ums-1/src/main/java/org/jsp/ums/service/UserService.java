package org.jsp.ums.service;


import java.util.List;
import java.util.Optional;

import org.jsp.ums.dao.UserDao;
import org.jsp.ums.entity.User;
import org.jsp.ums.responsestructure.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	UserDao dao;
    
	
	
    
	public ResponseEntity<?> saveUser(User user) {
		
		User savedUser=dao.savaUser(user);
		ResponseStructure rs= new ResponseStructure();
		rs.setStatus(201);
		rs.setMessege("user saved successfully....");
		rs.setBody(savedUser);
		return ResponseEntity.status(201).body(rs);
	}




	public ResponseEntity<?> findAllUsers() {
		List<User> allUsers=dao.findAllUsers();
		ResponseStructure rs= new ResponseStructure();
		rs.setStatus(200);
		rs.setMessege("all users found successfully");
		rs.setBody(allUsers);
		
		return ResponseEntity.status(200).body(rs);
	}




	public ResponseEntity<?> findUser(int id) {
		Optional<User> optional=dao.findUser(id);
		if(optional.isPresent()) {
			User user= optional.get();
			ResponseStructure rs= new ResponseStructure();
			rs.setStatus(200);
			rs.setMessege("user found successfully..");
			rs.setBody(user);
			return ResponseEntity.status(200).body(rs);
	  
	         }
		else {
			ResponseStructure rs= new ResponseStructure();
			rs.setStatus(202);
			rs.setMessege("user not found");
			rs.setBody(null);
			return ResponseEntity.status(200).body(rs);
	  
					
		}
		
		
		}

	public ResponseEntity<?> deleteUser(int id) {
		Optional<User> optional=dao.findUser(id);
		if(optional.isPresent()) {
			dao.deleteUser(id);
			ResponseStructure rs= new ResponseStructure(200,"deleted successfully","user deleted");
			return ResponseEntity.status(200).body(rs);
		}
		else {
			return ResponseEntity.status(400).body(new ResponseStructure(400, "invalid users", "inavlis users cannot delete"));
			
		}
	
	}
		
	
	  

	
}
